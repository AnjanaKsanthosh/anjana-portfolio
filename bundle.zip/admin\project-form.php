<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$project = [
    'title' => '',
    'description' => '',
    'technologies' => '',
    'category' => 'Web Development',
    'year' => date('Y'),
    'live_url' => '',
    'github_url' => '',
    'image' => '',
    'is_featured' => 0,
    'sort_order' => 0
];

if ($id > 0) {
    $stmt = db()->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        exit('Project not found.');
    }
    $project = $found;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach (['title', 'description', 'technologies', 'category', 'year', 'live_url', 'github_url', 'image'] as $field) {
        $project[$field] = trim($_POST[$field] ?? '');
    }
    $project['is_featured'] = isset($_POST['is_featured']) ? 1 : 0;
    $project['sort_order'] = (int)($_POST['sort_order'] ?? 0);

    if ($project['title'] === '') {
        $errors[] = 'Project title is required.';
    }
    if ($project['description'] === '') {
        $errors[] = 'Description is required.';
    }

    // Handle File Upload if provided
    if (!empty($_FILES['image_file']['name']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['image_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg', 'gif'];
        
        if (!in_array($ext, $allowed, true)) {
            $errors[] = 'Invalid image file type. Please upload JPG, PNG, WEBP, or SVG.';
        } elseif ($file['size'] > 5 * 1024 * 1024) {
            $errors[] = 'Uploaded image must be less than 5MB.';
        } else {
            $targetDir = __DIR__ . '/../assets/images/projects';
            if (!is_dir($targetDir)) {
                @mkdir($targetDir, 0777, true);
            }
            $cleanName = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
            $newFileName = time() . '_' . $cleanName . '.' . $ext;
            $destination = $targetDir . '/' . $newFileName;

            if (move_uploaded_file($file['tmp_name'], $destination)) {
                $project['image'] = 'assets/images/projects/' . $newFileName;
            } else {
                $errors[] = 'Failed to move uploaded file. Check directory write permissions.';
            }
        }
    }

    // URL validation if provided
    foreach (['live_url', 'github_url'] as $urlField) {
        if ($project[$urlField] !== '' && !filter_var($project[$urlField], FILTER_VALIDATE_URL)) {
            $errors[] = ucfirst(str_replace('_', ' ', $urlField)) . ' must be a valid URL with http:// or https://.';
        }
    }

    if (!$errors) {
        $values = [
            $project['title'],
            $project['description'],
            $project['technologies'],
            $project['category'],
            $project['year'],
            $project['live_url'],
            $project['github_url'],
            $project['image'],
            $project['is_featured'],
            $project['sort_order']
        ];

        if ($id > 0) {
            $values[] = $id;
            $stmt = db()->prepare("UPDATE projects SET title=?, description=?, technologies=?, category=?, year=?, live_url=?, github_url=?, image=?, is_featured=?, sort_order=? WHERE id=?");
            $stmt->execute($values);
            flash('success', 'Project updated successfully.');
        } else {
            $stmt = db()->prepare("INSERT INTO projects (title, description, technologies, category, year, live_url, github_url, image, is_featured, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute($values);
            flash('success', 'New project added successfully.');
        }

        header('Location: ' . url('admin/projects.php'));
        exit;
    }
}

include __DIR__ . '/_header.php';
?>
<div class="admin-title-row">
  <div>
    <h1 class="admin-title"><?= $id ? 'Edit Project' : 'Add New Project' ?></h1>
    <p class="muted">Fill in the details below. You can either upload an image or supply an image path.</p>
  </div>
  <a href="<?= e(url('admin/projects.php')) ?>" class="btn btn-ghost btn-sm">← Back to Projects</a>
</div>

<?php foreach ($errors as $error): ?>
  <div class="alert error"><?= e($error) ?></div>
<?php endforeach; ?>

<form class="admin-panel admin-form" method="post" enctype="multipart/form-data" action="<?= e(url('admin/project-form.php' . ($id ? '?id=' . $id : ''))) ?>">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

  <label class="form-field">
    <span class="field-label">Project Title <span class="req-star">*</span></span>
    <input type="text" name="title" required maxlength="150" value="<?= e($project['title']) ?>" placeholder="e.g. FamConnect – Direct Farmers Marketplace">
  </label>

  <label class="form-field">
    <span class="field-label">Detailed Description <span class="req-star">*</span></span>
    <textarea name="description" rows="4" required placeholder="Describe what the project accomplishes, the motivation, and key capabilities..."><?= e($project['description']) ?></textarea>
  </label>

  <div class="form-grid-two">
    <label class="form-field">
      <span class="field-label">Category</span>
      <input type="text" name="category" value="<?= e($project['category']) ?>" placeholder="Web Development, Web Application, Mobile, Networking...">
    </label>

    <label class="form-field">
      <span class="field-label">Year of Completion</span>
      <input type="text" name="year" value="<?= e($project['year']) ?>" placeholder="2025, 2026...">
    </label>
  </div>

  <label class="form-field">
    <span class="field-label">Technologies (Comma-separated list)</span>
    <input type="text" name="technologies" value="<?= e($project['technologies']) ?>" placeholder="PHP, MySQL, React.js, Tailwind CSS, Wireshark...">
  </label>

  <div class="form-grid-two">
    <label class="form-field">
      <span class="field-label">Live Demo URL</span>
      <input type="url" name="live_url" value="<?= e($project['live_url']) ?>" placeholder="https://example.com/demo">
    </label>

    <label class="form-field">
      <span class="field-label">GitHub Repository URL</span>
      <input type="url" name="github_url" value="<?= e($project['github_url']) ?>" placeholder="https://github.com/username/repo">
    </label>
  </div>

  <!-- Image Section: Upload file or path -->
  <div class="image-upload-card">
    <span class="field-label">Project Visual / Mockup Preview</span>
    <div class="image-fields-row">
      <div class="image-file-col">
        <label class="form-field">
          <span class="field-label">Upload Image File (JPG, PNG, WEBP, SVG)</span>
          <input type="file" name="image_file" accept=".jpg,.jpeg,.png,.webp,.svg,.gif">
        </label>
      </div>
      <div class="image-path-col">
        <label class="form-field">
          <span class="field-label">Or Custom Image Path</span>
          <input type="text" name="image" value="<?= e($project['image']) ?>" placeholder="assets/images/projects/project.svg">
        </label>
      </div>
    </div>

    <?php if (!empty($project['image'])): ?>
      <div class="current-image-preview">
        <span class="small muted">Current Image:</span><br>
        <img src="<?= e(url($project['image'])) ?>" alt="Preview" class="preview-img-box">
      </div>
    <?php endif; ?>
  </div>

  <div class="form-grid-two">
    <label class="form-field">
      <span class="field-label">Display Order (Lower numbers appear first)</span>
      <input type="number" name="sort_order" value="<?= (int)$project['sort_order'] ?>">
    </label>

    <label class="checkbox-custom-label">
      <input type="checkbox" name="is_featured" value="1" <?= !empty($project['is_featured']) ? 'checked' : '' ?>>
      <span>★ Feature this project on Homepage</span>
    </label>
  </div>

  <div class="form-actions-row">
    <button class="btn btn-primary" type="submit">
      <span><?= $id ? 'Save Changes' : 'Create Project' ?></span> ↗
    </button>
    <a class="btn btn-ghost" href="<?= e(url('admin/projects.php')) ?>">Cancel</a>
  </div>
</form>

<?php include __DIR__ . '/_footer.php'; ?>
