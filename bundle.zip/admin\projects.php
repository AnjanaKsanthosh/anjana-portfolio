<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

$db = db();
$errors = [];

// Handle Project Deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    verify_csrf();
    $deleteId = (int)($_POST['project_id'] ?? 0);
    if ($deleteId > 0) {
        $stmt = $db->prepare("DELETE FROM projects WHERE id = ?");
        $stmt->execute([$deleteId]);
        flash('success', 'Project successfully deleted.');
        header('Location: ' . url('admin/projects.php'));
        exit;
    }
}

// Handle Featured Toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_featured') {
    verify_csrf();
    $toggleId = (int)($_POST['project_id'] ?? 0);
    $currentVal = (int)($_POST['current_featured'] ?? 0);
    $newVal = $currentVal ? 0 : 1;
    if ($toggleId > 0) {
        $stmt = $db->prepare("UPDATE projects SET is_featured = ? WHERE id = ?");
        $stmt->execute([$newVal, $toggleId]);
        flash('success', 'Featured status updated.');
        header('Location: ' . url('admin/projects.php'));
        exit;
    }
}

$projects = $db->query("SELECT * FROM projects ORDER BY sort_order ASC, created_at DESC")->fetchAll();
$flashSuccess = flash('success');
include __DIR__ . '/_header.php';
?>
<div class="admin-title-row">
  <div>
    <h1 class="admin-title">Project Management</h1>
    <p class="muted">Add, modify, rearrange, and feature portfolio projects.</p>
  </div>
  <a href="<?= e(url('admin/project-form.php')) ?>" class="btn btn-primary btn-sm">
    <span>+ Add New Project</span>
  </a>
</div>

<?php if ($flashSuccess): ?>
  <div class="alert success"><?= e($flashSuccess) ?></div>
<?php endif; ?>

<div class="admin-panel">
  <?php if (!empty($projects)): ?>
    <div class="table-wrap">
      <table class="admin-table">
        <thead>
          <tr>
            <th style="width: 50px;">Order</th>
            <th style="width: 80px;">Preview</th>
            <th>Project Details</th>
            <th>Category</th>
            <th>Featured</th>
            <th>Live / GitHub</th>
            <th style="text-align: right;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($projects as $p): ?>
            <tr>
              <td>
                <span class="order-badge">#<?= (int)$p['sort_order'] ?></span>
              </td>
              <td>
                <div class="admin-thumb-box">
                  <?php if (!empty($p['image'])): ?>
                    <img src="<?= e(url($p['image'])) ?>" alt="<?= e($p['title']) ?>" class="admin-thumb-img">
                  <?php else: ?>
                    <span class="admin-thumb-ph"><?= strtoupper(substr($p['title'], 0, 1)) ?></span>
                  <?php endif; ?>
                </div>
              </td>
              <td>
                <strong class="project-name-cell"><?= e($p['title']) ?></strong>
                <p class="project-desc-cell"><?= e(mb_strimwidth($p['description'], 0, 90, '...')) ?></p>
                <div class="mini-tech-tags">
                  <?php foreach (array_slice(array_filter(array_map('trim', explode(',', $p['technologies'] ?? ''))), 0, 3) as $tech): ?>
                    <span class="m-tag"><?= e($tech) ?></span>
                  <?php endforeach; ?>
                </div>
              </td>
              <td>
                <span class="badge-cat"><?= e($p['category']) ?></span><br>
                <small class="muted"><?= e($p['year']) ?></small>
              </td>
              <td>
                <form method="post" action="<?= e(url('admin/projects.php')) ?>" style="display:inline;">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="toggle_featured">
                  <input type="hidden" name="project_id" value="<?= (int)$p['id'] ?>">
                  <input type="hidden" name="current_featured" value="<?= (int)$p['is_featured'] ?>">
                  <button type="submit" class="toggle-btn <?= $p['is_featured'] ? 'is-active' : '' ?>" title="Click to toggle homepage visibility">
                    <?= $p['is_featured'] ? '★ Featured' : '☆ Standard' ?>
                  </button>
                </form>
              </td>
              <td>
                <div class="link-pills-row">
                  <?php if (!empty($p['live_url'])): ?>
                    <a href="<?= e($p['live_url']) ?>" target="_blank" class="link-pill" title="Open live URL">Demo ↗</a>
                  <?php endif; ?>
                  <?php if (!empty($p['github_url'])): ?>
                    <a href="<?= e($p['github_url']) ?>" target="_blank" class="link-pill" title="Open source code">Code ↗</a>
                  <?php endif; ?>
                  <?php if (empty($p['live_url']) && empty($p['github_url'])): ?>
                    <span class="muted small">No links</span>
                  <?php endif; ?>
                </div>
              </td>
              <td style="text-align: right;">
                <div class="table-action-btns">
                  <a href="<?= e(url('admin/project-form.php?id=' . (int)$p['id'])) ?>" class="btn btn-xs btn-ghost">
                    Edit ✎
                  </a>
                  <form method="post" action="<?= e(url('admin/projects.php')) ?>" style="display:inline;" onsubmit="return confirm('Are you sure you want to permanently delete this project?');">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="project_id" value="<?= (int)$p['id'] ?>">
                    <button type="submit" class="btn btn-xs btn-danger">Delete ✕</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="empty-state">
      <p>No projects registered in database yet.</p>
      <a href="<?= e(url('admin/project-form.php')) ?>" class="btn btn-primary btn-sm">+ Add First Project</a>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/_footer.php'; ?>
