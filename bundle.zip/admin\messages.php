<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

$db = db();

// Handle Actions: mark_read, mark_unread, delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $msgId = (int)($_POST['message_id'] ?? 0);

    if ($msgId > 0) {
        if ($action === 'mark_read') {
            $stmt = $db->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
            $stmt->execute([$msgId]);
            flash('success', 'Message marked as read.');
        } elseif ($action === 'mark_unread') {
            $stmt = $db->prepare("UPDATE messages SET is_read = 0 WHERE id = ?");
            $stmt->execute([$msgId]);
            flash('success', 'Message marked as unread.');
        } elseif ($action === 'delete') {
            $stmt = $db->prepare("DELETE FROM messages WHERE id = ?");
            $stmt->execute([$msgId]);
            flash('success', 'Message deleted permanently.');
        }
    }
    header('Location: ' . url('admin/messages.php'));
    exit;
}

$filter = $_GET['filter'] ?? 'all';
$query = "SELECT * FROM messages";
if ($filter === 'unread') {
    $query .= " WHERE is_read = 0";
} elseif ($filter === 'read') {
    $query .= " WHERE is_read = 1";
}
$query .= " ORDER BY created_at DESC";

$messages = $db->query($query)->fetchAll();
$totalMessages = (int)$db->query("SELECT COUNT(*) FROM messages")->fetchColumn();
$unreadMessages = (int)$db->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn();

$flashSuccess = flash('success');
include __DIR__ . '/_header.php';
?>
<div class="admin-title-row">
  <div>
    <h1 class="admin-title">Inbox Messages</h1>
    <p class="muted">Review inquiries, collaborate requests, and recruiter messages.</p>
  </div>
  <div class="filter-pill-group">
    <a href="<?= e(url('admin/messages.php')) ?>" class="filter-pill-btn <?= $filter === 'all' ? 'active' : '' ?>">
      All (<?= $totalMessages ?>)
    </a>
    <a href="<?= e(url('admin/messages.php?filter=unread')) ?>" class="filter-pill-btn <?= $filter === 'unread' ? 'active' : '' ?>">
      Unread (<?= $unreadMessages ?>)
    </a>
    <a href="<?= e(url('admin/messages.php?filter=read')) ?>" class="filter-pill-btn <?= $filter === 'read' ? 'active' : '' ?>">
      Read (<?= $totalMessages - $unreadMessages ?>)
    </a>
  </div>
</div>

<?php if ($flashSuccess): ?>
  <div class="alert success"><?= e($flashSuccess) ?></div>
<?php endif; ?>

<div class="admin-panel">
  <?php if (!empty($messages)): ?>
    <div class="table-wrap">
      <table class="admin-table">
        <thead>
          <tr>
            <th style="width: 70px;">Status</th>
            <th>Sender Info</th>
            <th>Subject &amp; Message</th>
            <th>Timestamp</th>
            <th style="text-align: right;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($messages as $m): ?>
            <tr class="<?= empty($m['is_read']) ? 'row-unread' : '' ?>">
              <td>
                <?php if (empty($m['is_read'])): ?>
                  <span class="badge-unread">Unread</span>
                <?php else: ?>
                  <span class="badge-read">Read</span>
                <?php endif; ?>
              </td>
              <td>
                <strong class="sender-name"><?= e($m['name']) ?></strong><br>
                <a href="mailto:<?= e($m['email']) ?>" class="sender-email"><?= e($m['email']) ?></a>
              </td>
              <td>
                <strong class="msg-subject-line"><?= e($m['subject']) ?></strong>
                <div class="message-full-content"><?= nl2br(e($m['message'])) ?></div>
              </td>
              <td>
                <span class="date-text"><?= date('M d, Y · h:i A', strtotime($m['created_at'])) ?></span>
              </td>
              <td style="text-align: right;">
                <div class="table-action-btns">
                  <a href="mailto:<?= e($m['email']) ?>?subject=Re:%20<?= urlencode($m['subject']) ?>" class="btn btn-xs btn-primary" title="Reply via email client">
                    Reply ✉
                  </a>

                  <form method="post" action="<?= e(url('admin/messages.php')) ?>" style="display:inline;">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="<?= empty($m['is_read']) ? 'mark_read' : 'mark_unread' ?>">
                    <input type="hidden" name="message_id" value="<?= (int)$m['id'] ?>">
                    <button type="submit" class="btn btn-xs btn-ghost">
                      <?= empty($m['is_read']) ? 'Mark Read ✓' : 'Mark Unread' ?>
                    </button>
                  </form>

                  <form method="post" action="<?= e(url('admin/messages.php')) ?>" style="display:inline;" onsubmit="return confirm('Permanently delete this message?');">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="message_id" value="<?= (int)$m['id'] ?>">
                    <button type="submit" class="btn btn-xs btn-danger">Delete ✕</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="empty-state">
      <p>No messages match the current filter.</p>
      <?php if ($filter !== 'all'): ?>
        <a href="<?= e(url('admin/messages.php')) ?>" class="text-link">Show all messages</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/_footer.php'; ?>
