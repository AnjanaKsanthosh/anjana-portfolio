<?php
require_once __DIR__ . '/../config/config.php';
require_admin();
$adminPage = basename($_SERVER['PHP_SELF'] ?? '');
?>
<!doctype html>
<html lang="en" data-theme="obsidian">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Dashboard | <?= e(APP_NAME) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="admin-body">
<div class="admin-shell">
  <aside class="admin-sidebar">
    <a class="brand" href="<?= e(url('admin/dashboard.php')) ?>">
      <span class="brand-mark">
        <span class="brand-letter">A</span>
      </span>
      <span class="brand-text">Admin<span class="brand-dot">.</span></span>
    </a>

    <p class="admin-label">NAVIGATION</p>
    <a href="<?= e(url('admin/dashboard.php')) ?>" class="<?= $adminPage === 'dashboard.php' ? 'active' : '' ?>">
      <span>▦</span> Dashboard
    </a>
    <a href="<?= e(url('admin/projects.php')) ?>" class="<?= $adminPage === 'projects.php' || $adminPage === 'project-form.php' ? 'active' : '' ?>">
      <span>◇</span> Projects Manager
    </a>
    <a href="<?= e(url('admin/messages.php')) ?>" class="<?= $adminPage === 'messages.php' ? 'active' : '' ?>">
      <span>✉</span> Inbox Messages
    </a>

    <p class="admin-label">EXTERNAL</p>
    <a href="<?= e(url('index.php')) ?>" target="_blank" rel="noopener">
      <span>↗</span> View Public Website
    </a>
    <a href="<?= e(url('admin/logout.php')) ?>" class="logout-link">
      <span>↪</span> Sign Out
    </a>
  </aside>

  <main class="admin-main">
    <header class="admin-top">
      <div class="admin-breadcrumbs">
        <span>Portfolio Console</span> / <strong class="page-name"><?= e(ucfirst(str_replace(['.php', '-'], ['', ' '], $adminPage))) ?></strong>
      </div>
      <div class="admin-user-pill">
        <span class="online-indicator"></span>
        <span>Administrator (<?= e($_SESSION['admin_username'] ?? 'admin') ?>)</span>
      </div>
    </header>
