<?php
require_once __DIR__ . '/../config/config.php';
$pageTitle = $pageTitle ?? APP_NAME;
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
?>
<!doctype html>
<html lang="en" data-theme="obsidian">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Portfolio of Anjana K Santhosh — Computer Science graduate, Network Engineering scholar, and full-stack web developer.">
  <meta name="author" content="Anjana K Santhosh">
  <meta property="og:title" content="<?= e($pageTitle) ?> | <?= e(APP_NAME) ?>">
  <meta property="og:description" content="Explore projects, skills, and academic milestones in web engineering and network technologies.">
  <meta property="og:type" content="website">
  <title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=JetBrains+Mono:wght@400;500;600&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="site-body">
<!-- Background Canvas for Interactive Constellation & Ambient Light -->
<canvas id="ambientCanvas" class="ambient-canvas" aria-hidden="true"></canvas>

<!-- Custom Interactive Glowing Cursor -->
<div class="custom-cursor" id="customCursor" aria-hidden="true"></div>
<div class="cursor-dot" id="cursorDot" aria-hidden="true"></div>

<div class="site-shell">
<header class="site-header" id="siteHeader">
  <a class="brand" href="<?= e(url('index.php')) ?>" aria-label="Anjana K Santhosh Home">
    <span class="brand-mark">
      <span class="brand-letter">A</span>
      <span class="brand-sparkle">✦</span>
    </span>
    <span class="brand-text">Anjana<span class="brand-dot">.</span></span>
  </a>

  <nav class="main-nav" id="mainNav" aria-label="Main Navigation">
    <a class="<?= $currentPage === 'index.php' || $currentPage === '' ? 'active' : '' ?>" href="<?= e(url('index.php')) ?>">
      <span>01</span> Home
    </a>
    <a class="<?= $currentPage === 'about.php' ? 'active' : '' ?>" href="<?= e(url('about.php')) ?>">
      <span>02</span> About
    </a>
    <a class="<?= $currentPage === 'projects.php' ? 'active' : '' ?>" href="<?= e(url('projects.php')) ?>">
      <span>03</span> Projects
    </a>
    <a class="<?= $currentPage === 'skills.php' ? 'active' : '' ?>" href="<?= e(url('skills.php')) ?>">
      <span>04</span> Skills
    </a>
    <a class="<?= $currentPage === 'education.php' ? 'active' : '' ?>" href="<?= e(url('education.php')) ?>">
      <span>05</span> Education
    </a>
    <a class="<?= $currentPage === 'contact.php' ? 'active' : '' ?>" href="<?= e(url('contact.php')) ?>">
      <span>06</span> Contact
    </a>
  </nav>

  <div class="header-utilities">
    <!-- Sound Toggle -->
    <button class="util-btn" id="soundToggle" type="button" aria-label="Toggle Sound Effects" title="Toggle Sound FX">
      <span class="sound-icon sound-off">🔇</span>
      <span class="sound-icon sound-on" style="display:none">🔊</span>
    </button>

    <!-- Theme Switcher Button -->
    <div class="theme-dropdown-wrap">
      <button class="util-btn theme-toggle-btn" id="themeToggleBtn" type="button" aria-label="Change Theme" title="Switch Theme">
        <span class="theme-icon">🎨</span>
        <span class="theme-name" id="currentThemeName">Obsidian</span>
      </button>
      <div class="theme-menu" id="themeMenu">
        <button type="button" class="theme-opt active" data-set-theme="obsidian">
          <span class="theme-dot dot-obsidian"></span> Obsidian Violet
        </button>
        <button type="button" class="theme-opt" data-set-theme="cyber">
          <span class="theme-dot dot-cyber"></span> Cyber Neon
        </button>
        <button type="button" class="theme-opt" data-set-theme="emerald">
          <span class="theme-dot dot-emerald"></span> Midnight Emerald
        </button>
        <button type="button" class="theme-opt" data-set-theme="light">
          <span class="theme-dot dot-light"></span> Studio Light
        </button>
      </div>
    </div>

    <!-- Resume Trigger -->
    <button class="btn btn-sm btn-ghost resume-btn" id="openResumeBtn" type="button">
      Resume <span>📄</span>
    </button>

    <!-- Let's Talk CTA -->
    <a class="nav-cta" href="<?= e(url('contact.php')) ?>">
      Let's Talk <span class="arrow-up">↗</span>
    </a>

    <!-- Mobile Hamburger Toggle -->
    <button class="menu-toggle" id="menuToggle" aria-label="Toggle Navigation Menu" aria-expanded="false">
      <span class="hamburger-bar"></span>
      <span class="hamburger-bar"></span>
      <span class="hamburger-bar"></span>
    </button>
  </div>
</header>
<main id="mainContent">
