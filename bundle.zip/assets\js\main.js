/**
 * ANJANA K SANTHOSH — INTERACTIVE PORTFOLIO ENGINE
 * Features: Theme Engine, Audio Synthesizer, Dynamic Canvas, 3D Tilt,
 * Interactive Terminal, Live Search, Project Modal, Resume Modal, AJAX Contact
 */

(function () {
  'use strict';

  // ==========================================
  // 1. SOUND FX ENGINE (Web Audio API Synthesizer)
  // ==========================================
  let audioCtx = null;
  let soundEnabled = localStorage.getItem('portfolio_sound') === 'true';

  function initAudio() {
    if (!audioCtx && (window.AudioContext || window.webkitAudioContext)) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AudioContextClass();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playTone(freq = 440, type = 'sine', duration = 0.08, gainVal = 0.04) {
    if (!soundEnabled) return;
    try {
      initAudio();
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(gainVal, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {
      // Audio autoplay policy fallback
    }
  }

  const sfx = {
    click: () => playTone(600, 'sine', 0.05, 0.03),
    hover: () => playTone(350, 'triangle', 0.04, 0.015),
    terminal: () => playTone(820, 'square', 0.03, 0.02),
    success: () => {
      if (!soundEnabled) return;
      setTimeout(() => playTone(523.25, 'sine', 0.1, 0.04), 0);
      setTimeout(() => playTone(659.25, 'sine', 0.12, 0.04), 100);
      setTimeout(() => playTone(783.99, 'sine', 0.16, 0.05), 200);
    }
  };

  const soundToggle = document.getElementById('soundToggle');
  if (soundToggle) {
    const updateSoundUI = () => {
      const offIcon = soundToggle.querySelector('.sound-off');
      const onIcon = soundToggle.querySelector('.sound-on');
      if (soundEnabled) {
        if (offIcon) offIcon.style.display = 'none';
        if (onIcon) onIcon.style.display = 'inline';
        soundToggle.classList.add('sound-active');
        soundToggle.title = 'Sound Effects: Enabled (Click to Mute)';
      } else {
        if (offIcon) offIcon.style.display = 'inline';
        if (onIcon) onIcon.style.display = 'none';
        soundToggle.classList.remove('sound-active');
        soundToggle.title = 'Sound Effects: Muted (Click to Unmute)';
      }
    };
    updateSoundUI();

    soundToggle.addEventListener('click', () => {
      initAudio();
      soundEnabled = !soundEnabled;
      localStorage.setItem('portfolio_sound', String(soundEnabled));
      updateSoundUI();
      if (soundEnabled) sfx.success();
    });
  }

  // ==========================================
  // 2. THEME ENGINE
  // ==========================================
  const themeNames = {
    obsidian: 'Obsidian',
    cyber: 'Cyber Neon',
    emerald: 'Emerald',
    light: 'Studio Light'
  };

  const savedTheme = localStorage.getItem('portfolio_theme') || 'obsidian';
  function applyTheme(themeKey) {
    if (!themeNames[themeKey]) themeKey = 'obsidian';
    document.documentElement.setAttribute('data-theme', themeKey);
    localStorage.setItem('portfolio_theme', themeKey);
    const themeNameElem = document.getElementById('currentThemeName');
    if (themeNameElem) themeNameElem.textContent = themeNames[themeKey];

    document.querySelectorAll('.theme-opt').forEach(opt => {
      opt.classList.toggle('active', opt.dataset.setTheme === themeKey);
    });
  }
  applyTheme(savedTheme);

  const themeDropdownWrap = document.querySelector('.theme-dropdown-wrap');
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  if (themeToggleBtn && themeDropdownWrap) {
    themeToggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      themeDropdownWrap.classList.toggle('open');
      sfx.click();
    });

    document.addEventListener('click', () => {
      themeDropdownWrap.classList.remove('open');
    });

    document.querySelectorAll('.theme-opt').forEach(opt => {
      opt.addEventListener('click', () => {
        const targetTheme = opt.dataset.setTheme;
        applyTheme(targetTheme);
        themeDropdownWrap.classList.remove('open');
        sfx.click();
      });
    });
  }

  // ==========================================
  // 3. BACKGROUND AMBIENT CONSTELLATION CANVAS
  // ==========================================
  const canvas = document.getElementById('ambientCanvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width, height;
    let particles = [];
    const particleCount = 45;
    const maxDistance = 140;
    let mouse = { x: null, y: null, radius: 150 };

    function resize() {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    window.addEventListener('mousemove', (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    });

    window.addEventListener('mouseout', () => {
      mouse.x = null;
      mouse.y = null;
    });

    class Particle {
      constructor() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.5) * 0.45;
        this.vy = (Math.random() - 0.5) * 0.45;
        this.radius = Math.random() * 2 + 1;
      }
      update() {
        this.x += this.vx;
        this.y += this.vy;

        if (this.x < 0 || this.x > width) this.vx *= -1;
        if (this.y < 0 || this.y > height) this.vy *= -1;

        if (mouse.x !== null) {
          const dx = mouse.x - this.x;
          const dy = mouse.y - this.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < mouse.radius) {
            const force = (mouse.radius - dist) / mouse.radius;
            this.x -= (dx / dist) * force * 1.5;
            this.y -= (dy / dist) * force * 1.5;
          }
        }
      }
      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        const isLight = document.documentElement.getAttribute('data-theme') === 'light';
        ctx.fillStyle = isLight ? 'rgba(99, 102, 241, 0.4)' : 'rgba(167, 139, 250, 0.5)';
        ctx.fill();
      }
    }

    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle());
    }

    function animateCanvas() {
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < particles.length; i++) {
        particles[i].update();
        particles[i].draw();

        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxDistance) {
            const alpha = (1 - dist / maxDistance) * 0.22;
            const isLight = document.documentElement.getAttribute('data-theme') === 'light';
            ctx.beginPath();
            ctx.strokeStyle = isLight
              ? `rgba(99, 102, 241, ${alpha})`
              : `rgba(167, 139, 250, ${alpha})`;
            ctx.lineWidth = 1;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(animateCanvas);
    }
    animateCanvas();
  }

  // ==========================================
  // 4. CUSTOM CURSOR
  // ==========================================
  const cursor = document.getElementById('customCursor');
  const cursorDot = document.getElementById('cursorDot');
  if (cursor && cursorDot && window.matchMedia('(pointer: fine)').matches) {
    let mouseX = -100, mouseY = -100;
    let cursorX = -100, cursorY = -100;

    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursorDot.style.transform = `translate(${mouseX}px, ${mouseY}px)`;
    });

    function loopCursor() {
      cursorX += (mouseX - cursorX) * 0.18;
      cursorY += (mouseY - cursorY) * 0.18;
      cursor.style.transform = `translate(${cursorX}px, ${cursorY}px)`;
      requestAnimationFrame(loopCursor);
    }
    loopCursor();

    const hoverTargets = document.querySelectorAll('a, button, input, textarea, .project-card, .value-card, .experience-box');
    hoverTargets.forEach(el => {
      el.addEventListener('mouseenter', () => {
        cursor.classList.add('hovering');
        sfx.hover();
      });
      el.addEventListener('mouseleave', () => {
        cursor.classList.remove('hovering');
      });
    });
  }

  // ==========================================
  // 5. 3D CARD TILT EFFECT (HERO PROFILE)
  // ==========================================
  const profileCard = document.getElementById('profile3dCard');
  if (profileCard) {
    profileCard.addEventListener('mousemove', (e) => {
      const rect = profileCard.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = ((y - centerY) / centerY) * -12;
      const rotateY = ((x - centerX) / centerX) * 12;

      profileCard.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
    });

    profileCard.addEventListener('mouseleave', () => {
      profileCard.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
    });
  }

  // ==========================================
  // 6. TYPEWRITER EFFECT
  // ==========================================
  const typedElem = document.getElementById('typedText');
  if (typedElem) {
    const roles = [
      'Computer Science Graduate',
      'Network Engineering Scholar',
      'Full-Stack Web Developer',
      'Cyber Threat Defense Builder',
      'Curious Technology Explorer'
    ];
    let roleIdx = 0;
    let charIdx = 0;
    let isDeleting = false;

    function typeLoop() {
      const currentRole = roles[roleIdx];
      if (!isDeleting) {
        charIdx++;
        typedElem.textContent = currentRole.substring(0, charIdx);
        if (charIdx === currentRole.length) {
          isDeleting = true;
          setTimeout(typeLoop, 1600);
          return;
        }
        setTimeout(typeLoop, 80);
      } else {
        charIdx--;
        typedElem.textContent = currentRole.substring(0, charIdx);
        if (charIdx === 0) {
          isDeleting = false;
          roleIdx = (roleIdx + 1) % roles.length;
          setTimeout(typeLoop, 300);
          return;
        }
        setTimeout(typeLoop, 40);
      }
    }
    typeLoop();
  }

  // ==========================================
  // 7. LIVE CLOCK (KERALA IST)
  // ==========================================
  function updateLiveClock() {
    const now = new Date();
    // Format to Indian Standard Time (Asia/Kolkata)
    const options = {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    };
    const timeStr = now.toLocaleTimeString('en-US', options) + ' IST';
    const heroClock = document.getElementById('heroClock');
    const footerClock = document.getElementById('footerClock');
    if (heroClock) heroClock.textContent = timeStr;
    if (footerClock) footerClock.textContent = timeStr;
  }
  updateLiveClock();
  setInterval(updateLiveClock, 1000);

  // ==========================================
  // 8. MOBILE NAVIGATION MENU
  // ==========================================
  const menuToggle = document.getElementById('menuToggle');
  const mainNav = document.getElementById('mainNav');
  if (menuToggle && mainNav) {
    menuToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', String(isOpen));
      sfx.click();
    });

    document.addEventListener('click', (e) => {
      if (!mainNav.contains(e.target) && !menuToggle.contains(e.target)) {
        mainNav.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // ==========================================
  // 9. RESUME MODAL HANDLERS
  // ==========================================
  const resumeModal = document.getElementById('resumeModal');
  const closeResumeBtn = document.getElementById('closeResumeBtn');
  const resumeTriggers = [
    document.getElementById('openResumeBtn'),
    document.getElementById('heroResumeTrigger'),
    document.getElementById('eduResumeTrigger')
  ].filter(Boolean);

  function openResume() {
    if (resumeModal) {
      resumeModal.removeAttribute('hidden');
      requestAnimationFrame(() => resumeModal.classList.add('open'));
      document.body.style.overflow = 'hidden';
      sfx.click();
    }
  }

  function closeResume() {
    if (resumeModal) {
      resumeModal.classList.remove('open');
      setTimeout(() => {
        resumeModal.setAttribute('hidden', '');
        document.body.style.overflow = '';
      }, 250);
      sfx.click();
    }
  }

  resumeTriggers.forEach(btn => btn.addEventListener('click', openResume));
  if (closeResumeBtn) closeResumeBtn.addEventListener('click', closeResume);
  if (resumeModal) {
    resumeModal.addEventListener('click', (e) => {
      if (e.target === resumeModal) closeResume();
    });
  }

  // ==========================================
  // 10. PROJECT DETAIL MODAL
  // ==========================================
  const projectModal = document.getElementById('projectModal');
  const closeProjectModalBtn = document.getElementById('closeProjectModalBtn');
  const modalProjectBody = document.getElementById('modalProjectBody');

  function openProjectModal(card) {
    if (!projectModal || !modalProjectBody || !card) return;
    const title = card.dataset.title || 'Project';
    const category = card.dataset.category || '';
    const year = card.dataset.year || '';
    const desc = card.dataset.description || '';
    const tech = card.dataset.technologies || '';
    const img = card.dataset.image || '';
    const live = card.dataset.live || '';
    const github = card.dataset.github || '';

    const tagsArr = tech.split(',').map(t => t.trim()).filter(Boolean);
    const tagsHtml = tagsArr.map(t => `<span class="tag-chip">${t}</span>`).join(' ');

    modalProjectBody.innerHTML = `
      ${img ? `<img src="${img}" alt="${title} banner preview">` : ''}
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span class="project-category-pill" style="position:static;">${category}</span>
        ${year ? `<span class="score-badge">${year}</span>` : ''}
      </div>
      <h2>${title}</h2>
      <p style="margin:16px 0; font-size:14.5px; line-height:1.75;">${desc}</p>
      <div style="margin:20px 0;">
        <strong style="display:block; font-size:12px; color:var(--purple); margin-bottom:8px;">ENGINEERED WITH:</strong>
        <div class="tag-list">${tagsHtml}</div>
      </div>
      <div class="project-footer-actions" style="margin-top:20px; padding-top:18px;">
        ${live ? `<a class="btn btn-primary btn-sm" href="${live}" target="_blank" rel="noopener">Launch Live Demo ↗</a>` : ''}
        ${github ? `<a class="btn btn-ghost btn-sm" href="${github}" target="_blank" rel="noopener">GitHub Repository ↗</a>` : ''}
      </div>
    `;

    projectModal.removeAttribute('hidden');
    requestAnimationFrame(() => projectModal.classList.add('open'));
    document.body.style.overflow = 'hidden';
    sfx.click();
  }

  function closeProjectModal() {
    if (projectModal) {
      projectModal.classList.remove('open');
      setTimeout(() => {
        projectModal.setAttribute('hidden', '');
        document.body.style.overflow = '';
      }, 250);
      sfx.click();
    }
  }

  document.querySelectorAll('.project-card').forEach(card => {
    // Click on image or overview button opens modal
    const viewBtn = card.querySelector('.view-project-btn');
    const overviewBtn = card.querySelector('.view-details-trigger');
    const titleLink = card.querySelector('.project-title');
    const arrowIcon = card.querySelector('.project-arrow-icon');

    [viewBtn, overviewBtn, titleLink, arrowIcon].filter(Boolean).forEach(trigger => {
      trigger.addEventListener('click', (e) => {
        e.preventDefault();
        openProjectModal(card);
      });
    });
  });

  if (closeProjectModalBtn) closeProjectModalBtn.addEventListener('click', closeProjectModal);
  if (projectModal) {
    projectModal.addEventListener('click', (e) => {
      if (e.target === projectModal) closeProjectModal();
    });
  }

  // Global ESC key listener for modals
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeResume();
      closeProjectModal();
      closeTerminal();
    }
  });

  // ==========================================
  // 11. PROJECTS SEARCH & FILTER (PROJECTS.PHP)
  // ==========================================
  const searchInput = document.getElementById('projectSearchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');
  const filterBtns = document.querySelectorAll('.filter-btn');
  const filterItems = document.querySelectorAll('.filter-item');
  const noFilterResults = document.getElementById('noFilterResults');
  const resetFiltersBtn = document.getElementById('resetFiltersBtn');

  let activeCategory = 'all';
  let activeSearch = '';

  function applyProjectFilters() {
    let visibleCount = 0;
    filterItems.forEach(item => {
      const itemCategory = item.dataset.category || '';
      const searchTerms = item.dataset.searchTerms || '';

      const matchesCat = (activeCategory === 'all' || itemCategory === activeCategory);
      const matchesSearch = (!activeSearch || searchTerms.includes(activeSearch));

      if (matchesCat && matchesSearch) {
        item.style.display = '';
        visibleCount++;
      } else {
        item.style.display = 'none';
      }
    });

    if (noFilterResults) {
      noFilterResults.hidden = (visibleCount > 0);
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      activeSearch = e.target.value.toLowerCase().trim();
      if (clearSearchBtn) clearSearchBtn.hidden = !activeSearch;
      applyProjectFilters();
    });
  }

  if (clearSearchBtn) {
    clearSearchBtn.addEventListener('click', () => {
      searchInput.value = '';
      activeSearch = '';
      clearSearchBtn.hidden = true;
      applyProjectFilters();
      searchInput.focus();
    });
  }

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');
      activeCategory = btn.dataset.filter;
      applyProjectFilters();
      sfx.click();
    });
  });

  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener('click', () => {
      if (searchInput) searchInput.value = '';
      activeSearch = '';
      if (clearSearchBtn) clearSearchBtn.hidden = true;
      activeCategory = 'all';
      filterBtns.forEach(b => {
        b.classList.toggle('active', b.dataset.filter === 'all');
      });
      applyProjectFilters();
      sfx.click();
    });
  }

  // ==========================================
  // 12. INTERACTIVE BASH TERMINAL
  // ==========================================
  const terminalDrawer = document.getElementById('terminalDrawer');
  const openTerminalBtn = document.getElementById('openTerminalBtn');
  const launchTermBtn = document.getElementById('launchTermBtn');
  const closeTerminalBtn = document.getElementById('closeTerminalBtn');
  const terminalForm = document.getElementById('terminalForm');
  const terminalInput = document.getElementById('terminalInput');
  const terminalOutput = document.getElementById('terminalOutput');
  const termChips = document.querySelectorAll('.term-chip');

  function openTerminal() {
    if (terminalDrawer) {
      terminalDrawer.removeAttribute('hidden');
      if (terminalInput) terminalInput.focus();
      sfx.terminal();
    }
  }

  function closeTerminal() {
    if (terminalDrawer) {
      terminalDrawer.setAttribute('hidden', '');
    }
  }

  if (openTerminalBtn) openTerminalBtn.addEventListener('click', openTerminal);
  if (launchTermBtn) launchTermBtn.addEventListener('click', openTerminal);
  if (closeTerminalBtn) closeTerminalBtn.addEventListener('click', closeTerminal);

  const termCommands = {
    help: () => `
COMMANDS AVAILABLE:
  help        - Display this command dictionary
  whoami      - Learn about Anjana K Santhosh
  skills      - List core engineering and technical skills
  projects    - Summary of featured repositories & portals
  education   - Academic qualifications and milestones
  contact     - Reach out via email, GitHub, or LinkedIn
  matrix      - Trigger matrix digital rain
  date        - View system date and local Kerala time
  clear       - Clear the terminal console buffer
`,
    whoami: () => `
USER: Anjana K Santhosh
ROLE: Computer Science Graduate & M.Tech Network Engineering Scholar
LOCATION: Kerala, India
FOCUS: Computer Networks, Full-Stack Web Development, Cyber Threat Defense.
PHILOSOPHY: Turning curiosity into robust, real-world digital solutions.
`,
    skills: () => `
CORE COMPETENCIES:
  • Languages:     PHP 8, JavaScript (ES6+), HTML5, CSS3, SQL
  • Frameworks:    React.js, Node.js, Express.js, Tailwind CSS
  • Databases:     MySQL, PostgreSQL, SQLite, PDO Prepared Statements
  • Networks:      TCP/IP Protocols, Routing, Wireshark, AI Scam Defense
  • Environments:  Apache, XAMPP, Git, GitHub, VS Code, Postman
`,
    projects: () => `
FEATURED PROJECTS:
  1. FamConnect – Direct Farmers Marketplace (Tink-Her-Hack)
  2. Placement Management System (React, Tailwind, Node, Postgres)
  3. SaferNet – Anti-Scam SMS Shield (Kerala Police Academy)
  4. Enterprise Employee Management (PHP 8, MySQL)
  5. Student Mark Entry System (PHP, MySQL, Analytics)
  6. Career Map & Pathway Explorer (Interactive JS)
`,
    education: () => `
ACADEMIC TIMELINE:
  • 2026–Present: M.Tech in Network Engineering
                  Government Engineering College, Barton Hill
  • 2023–2026:    B.Tech in Computer Science and Engineering
                  Rajiv Gandhi Institute of Technology (RIT), Kottayam
  • 2020–2023:    Diploma in Computer Science and Engineering
                  CGPA: 9.3 (Distinction)
`,
    contact: () => `
DIRECT CONTACT CHANNELS:
  • Email:    ${window.PORTFOLIO_EMAIL || 'anjanaksanthosh2002@gmail.com'}
  • GitHub:   https://github.com/
  • LinkedIn: https://www.linkedin.com/
  • Location: Kerala, India (IST)
`,
    date: () => `CURRENT TIME: ${new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })} (Asia/Kolkata IST)`,
    matrix: () => `[MATRIX ACTIVATED] Wake up, Neo... Follow the white rabbit. 01000001 01101110 01101010 01100001 01101110 01100001`,
    clear: () => null
  };

  function executeCommand(rawCmd) {
    const cmd = rawCmd.trim().toLowerCase();
    sfx.terminal();

    if (cmd === 'clear') {
      terminalOutput.innerHTML = '';
      return;
    }

    const cmdLine = document.createElement('div');
    cmdLine.className = 'term-line cmd';
    cmdLine.textContent = `visitor@anjana-portfolio:~$ ${rawCmd}`;
    terminalOutput.appendChild(cmdLine);

    const outLine = document.createElement('div');
    outLine.className = 'term-line out';

    if (termCommands[cmd]) {
      const res = termCommands[cmd]();
      if (res) outLine.textContent = res;
    } else if (cmd) {
      outLine.textContent = `bash: command not found: ${cmd}. Type 'help' to see valid commands.`;
    }

    terminalOutput.appendChild(outLine);
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
  }

  if (terminalForm) {
    terminalForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = terminalInput.value;
      if (val.trim()) {
        executeCommand(val);
        terminalInput.value = '';
      }
    });
  }

  termChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const cmd = chip.dataset.cmd;
      executeCommand(cmd);
      if (terminalInput) terminalInput.focus();
    });
  });

  // ==========================================
  // 13. CONTACT FORM AJAX & TOPIC CHIPS
  // ==========================================
  const contactForm = document.getElementById('contactForm');
  const formAlertBox = document.getElementById('formAlertBox');
  const submitContactBtn = document.getElementById('submitContactBtn');
  const contactSubject = document.getElementById('contactSubject');
  const topicChips = document.querySelectorAll('.topic-chip');
  const contactMessage = document.getElementById('contactMessage');
  const charCounter = document.getElementById('charCounter');
  const copyEmailBtn = document.getElementById('copyEmailBtn');

  // Topic chips auto-fill subject
  topicChips.forEach(chip => {
    chip.addEventListener('click', () => {
      topicChips.forEach(c => c.classList.remove('selected'));
      chip.classList.add('selected');
      if (contactSubject) {
        contactSubject.value = chip.dataset.subject;
        contactSubject.focus();
      }
      sfx.click();
    });
  });

  // Character counter
  if (contactMessage && charCounter) {
    contactMessage.addEventListener('input', () => {
      const count = contactMessage.value.length;
      charCounter.textContent = `${count} / 5000`;
      if (count > 4800) charCounter.style.color = '#ff65a3';
      else charCounter.style.color = '';
    });
  }

  // 1-Click Copy Email
  if (copyEmailBtn) {
    copyEmailBtn.addEventListener('click', () => {
      const email = copyEmailBtn.dataset.email;
      if (navigator.clipboard) {
        navigator.clipboard.writeText(email).then(() => {
          const original = copyEmailBtn.innerHTML;
          copyEmailBtn.innerHTML = '<span>Copied!</span> ✓';
          copyEmailBtn.style.color = 'var(--green)';
          sfx.success();
          setTimeout(() => {
            copyEmailBtn.innerHTML = original;
            copyEmailBtn.style.color = '';
          }, 2000);
        });
      }
    });
  }

  // Contact Form AJAX Submit
  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      sfx.click();

      const btnText = submitContactBtn.querySelector('.btn-text');
      const btnSpinner = submitContactBtn.querySelector('.btn-spinner');
      submitContactBtn.disabled = true;
      if (btnText) btnText.style.display = 'none';
      if (btnSpinner) btnSpinner.style.display = 'inline';

      const formData = new FormData(contactForm);

      try {
        const response = await fetch(contactForm.action, {
          method: 'POST',
          body: formData,
          headers: {
            'X-Requested-With': 'XMLHttpRequest'
          }
        });

        const data = await response.json();

        if (response.ok && data.success) {
          formAlertBox.innerHTML = `<div class="alert success" role="alert">${data.message}</div>`;
          contactForm.reset();
          if (charCounter) charCounter.textContent = '0 / 5000';
          topicChips.forEach(c => c.classList.remove('selected'));
          sfx.success();
        } else {
          const errList = (data.errors || [data.message || 'An error occurred.']).map(err => `<div>• ${err}</div>`).join('');
          formAlertBox.innerHTML = `<div class="alert error" role="alert">${errList}</div>`;
        }
      } catch (err) {
        // Fallback to traditional POST submission if fetch fails
        contactForm.submit();
        return;
      } finally {
        submitContactBtn.disabled = false;
        if (btnText) btnText.style.display = 'inline';
        if (btnSpinner) btnSpinner.style.display = 'none';
        formAlertBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    });
  }

  // ==========================================
  // 14. SCROLL REVEAL OBSERVER
  // ==========================================
  const revealElements = document.querySelectorAll('.reveal, .value-card, .timeline-entry, .experience-box, .skill-category-box, .pillar-card');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    revealElements.forEach(el => observer.observe(el));
  } else {
    revealElements.forEach(el => el.classList.add('visible'));
  }

  // ==========================================
  // 15. BACK TO TOP
  // ==========================================
  const backToTop = document.getElementById('backToTop');
  if (backToTop) {
    backToTop.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      sfx.click();
    });
  }

})();
