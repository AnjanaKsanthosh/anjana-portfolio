<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

$db = db();
$projectCount = (int)$db->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$featuredCount = (int)$db->query("SELECT COUNT(*) FROM projects WHERE is_featured = 1")->fetchColumn();
$messageCount = (int)$db->query("SELECT COUNT(*) FROM messages")->fetchColumn();
$unreadCount = (int)$db->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn();
$latest = $db->query("SELECT id, name, email, subject, message, is_read, created_at FROM messages ORDER BY created_at DESC LIMIT 5")->fetchAll();

$flashSuccess = flash('success');
include __DIR__ . '/_header.php';
?>
<div class="admin-dashboard-wrap">
  <?php if ($flashSuccess): ?>
    <div class="alert success"><?= e($flashSuccess) ?></div>
  <?php endif; ?>

  <div class="admin-title-row">
    <div>
      <h1 class="admin-title">Executive Dashboard</h1>
      <p class="muted">Live summary and control center for Anjana K Santhosh Portfolio.</p>
    </div>
    <div class="title-actions">
      <a href="<?= e(url('admin/project-form.php')) ?>" class="btn btn-primary btn-sm">
        <span>+ Add New Project</span>
      </a>
      <a href="<?= e(url('admin/messages.php')) ?>" class="btn btn-ghost btn-sm">
        <span>✉ View Inbox (<?= $unreadCount ?> new)</span>
      </a>
    </div>
  </div>

  <!-- Metric Statistics Cards -->
  <div class="admin-stats-grid">
    <div class="stat-card">
      <div class="stat-card-top">
        <span class="stat-name">TOTAL PROJECTS</span>
        <span class="stat-badge"><?= $featuredCount ?> featured</span>
      </div>
      <strong class="stat-big-val"><?= $projectCount ?></strong>
      <a href="<?= e(url('admin/projects.php')) ?>" class="stat-link">Manage projects archive →</a>
    </div>

    <div class="stat-card">
      <div class="stat-card-top">
        <span class="stat-name">INBOX MESSAGES</span>
        <span class="stat-badge">Total</span>
      </div>
      <strong class="stat-big-val"><?= $messageCount ?></strong>
      <a href="<?= e(url('admin/messages.php')) ?>" class="stat-link">View all contact submissions →</a>
    </div>

    <div class="stat-card highlight-card">
      <div class="stat-card-top">
        <span class="stat-name">UNREAD INQUIRIES</span>
        <span class="stat-badge new-badge"><?= $unreadCount ?> unread</span>
      </div>
      <strong class="stat-big-val <?= $unreadCount > 0 ? 'unread-glow' : '' ?>"><?= $unreadCount ?></strong>
      <a href="<?= e(url('admin/messages.php')) ?>" class="stat-link">Review pending messages →</a>
    </div>
  </div>

  <!-- Quick System Info & Health -->
  <div class="admin-grid-two">
    <!-- Recent Messages Panel -->
    <div class="admin-panel">
      <div class="panel-heading">
        <div>
          <h2>Recent Inquiries</h2>
          <p class="muted small">Latest incoming messages from visitors & recruiters.</p>
        </div>
        <a class="text-link" href="<?= e(url('admin/messages.php')) ?>">Open Full Inbox ↗</a>
      </div>

      <?php if (!empty($latest)): ?>
        <div class="table-wrap">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Status</th>
                <th>Sender</th>
                <th>Subject</th>
                <th>Received</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($latest as $m): ?>
                <tr class="<?= empty($m['is_read']) ? 'row-unread' : '' ?>">
                  <td>
                    <?php if (empty($m['is_read'])): ?>
                      <span class="badge-unread">New</span>
                    <?php else: ?>
                      <span class="badge-read">Read</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <strong><?= e($m['name']) ?></strong><br>
                    <small class="muted"><?= e($m['email']) ?></small>
                  </td>
                  <td>
                    <span class="subject-text"><?= e($m['subject']) ?></span>
                  </td>
                  <td>
                    <span class="date-text"><?= date('M d, Y', strtotime($m['created_at'])) ?></span>
                  </td>
                  <td>
                    <a href="mailto:<?= e($m['email']) ?>?subject=Re:%20<?= urlencode($m['subject']) ?>" class="btn btn-xs btn-ghost" title="Reply via email">
                      Reply ✉
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="empty-state-mini">
          <p>No messages received yet. Submit a test message through the public contact form.</p>
          <a href="<?= e(url('contact.php')) ?>" target="_blank" class="text-link">Go to contact form ↗</a>
        </div>
      <?php endif; ?>
    </div>

    <!-- Quick Shortcuts & System Health -->
    <div class="admin-panel">
      <div class="panel-heading">
        <h2>Environment &amp; Server</h2>
      </div>
      <div class="system-health-list">
        <div class="health-item">
          <span>Database Driver</span>
          <strong>MySQL / PDO Active</strong>
        </div>
        <div class="health-item">
          <span>Database Name</span>
          <code><?= e(DB_NAME) ?></code>
        </div>
        <div class="health-item">
          <span>PHP Environment</span>
          <strong>PHP <?= PHP_VERSION ?></strong>
        </div>
        <div class="health-item">
          <span>Base Path</span>
          <code><?= e(BASE_URL ?: '/') ?></code>
        </div>
        <div class="health-item">
          <span>XAMPP Apache Server</span>
          <strong class="text-success">Active &amp; Linked</strong>
        </div>
      </div>

      <div class="panel-actions-box">
        <h3>Quick Navigation</h3>
        <div class="quick-btn-grid">
          <a href="<?= e(url('admin/project-form.php')) ?>" class="quick-action-pill">+ Add Project</a>
          <a href="<?= e(url('admin/projects.php')) ?>" class="quick-action-pill">Manage Projects</a>
          <a href="<?= e(url('admin/messages.php')) ?>" class="quick-action-pill">Review Messages</a>
          <a href="<?= e(url('index.php')) ?>" target="_blank" class="quick-action-pill">Preview Portfolio ↗</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/_footer.php'; ?>
