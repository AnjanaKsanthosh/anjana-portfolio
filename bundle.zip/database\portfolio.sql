-- Anjana K Santhosh Portfolio Database Schema & Seed Data
CREATE DATABASE IF NOT EXISTS `anjana_portfolio` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `anjana_portfolio`;

-- Administrators table
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(40) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Projects table
CREATE TABLE IF NOT EXISTS `projects` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(150) NOT NULL,
  `description` TEXT NOT NULL,
  `technologies` VARCHAR(500) DEFAULT '',
  `category` VARCHAR(80) DEFAULT 'Other',
  `year` VARCHAR(20) DEFAULT '',
  `live_url` VARCHAR(500) DEFAULT '',
  `github_url` VARCHAR(500) DEFAULT '',
  `image` VARCHAR(500) DEFAULT '',
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Messages table
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `subject` VARCHAR(160) NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default Admin Account: admin / Admin@2026!
INSERT INTO `admins` (`id`, `username`, `password_hash`)
SELECT 1, 'admin', '$2y$10$wE0v7VnK2O03kC6O18e.yeM7o8z20Z91E5a4V1o2w3x4y5z6a7b8c'
WHERE NOT EXISTS (SELECT 1 FROM `admins` LIMIT 1);

-- Default Featured & Portfolio Projects
INSERT INTO `projects` (`title`, `description`, `technologies`, `category`, `year`, `live_url`, `github_url`, `image`, `is_featured`, `sort_order`)
SELECT 'FamConnect – Farmers Marketplace',
'A direct-to-consumer agricultural platform concept designed to connect farmers directly with consumers, eliminate intermediaries, and ensure sustainable, fair pricing.',
'HTML5, CSS3, JavaScript, Responsive Design',
'Web Development',
'2025',
'https://asmapa.github.io/Farm_connect/',
'https://github.com/asmapa/Farm_connect',
'assets/images/projects/famconnect.svg',
1,
1
WHERE NOT EXISTS (SELECT 1 FROM `projects` WHERE `title` LIKE 'FamConnect%');

INSERT INTO `projects` (`title`, `description`, `technologies`, `category`, `year`, `live_url`, `github_url`, `image`, `is_featured`, `sort_order`)
SELECT 'Placement Management System',
'A comprehensive campus recruitment portal concept for student qualification tracking, corporate recruiters, and real-time round-by-round interview status updates.',
'React, Tailwind CSS, Node.js, Express, PostgreSQL',
'Web Application',
'2025',
'',
'',
'assets/images/projects/placement.svg',
1,
2
WHERE NOT EXISTS (SELECT 1 FROM `projects` WHERE `title` LIKE 'Placement Management%');

INSERT INTO `projects` (`title`, `description`, `technologies`, `category`, `year`, `live_url`, `github_url`, `image`, `is_featured`, `sort_order`)
SELECT 'SaferNet – Anti-Scam SMS Shield',
'An Android application built during an internship at Kerala Police Academy to intercept phishing messages, analyze scam hyperlinks, and raise cyber fraud awareness.',
'Android, Java/Kotlin, AI Heuristics, Cyber Safety',
'Mobile Application',
'2025',
'',
'',
'assets/images/projects/safernet.svg',
1,
3
WHERE NOT EXISTS (SELECT 1 FROM `projects` WHERE `title` LIKE 'SaferNet%');

INSERT INTO `projects` (`title`, `description`, `technologies`, `category`, `year`, `live_url`, `github_url`, `image`, `is_featured`, `sort_order`)
SELECT 'Employee Management System',
'A full-featured human resources web application for managing staff personnel profiles, departments, attendance, and leave workflows.',
'PHP, MySQL, HTML5, CSS3, JavaScript',
'Web Application',
'2024',
'',
'',
'assets/images/projects/employee.svg',
0,
4
WHERE NOT EXISTS (SELECT 1 FROM `projects` WHERE `title` LIKE 'Employee Management%');

INSERT INTO `projects` (`title`, `description`, `technologies`, `category`, `year`, `live_url`, `github_url`, `image`, `is_featured`, `sort_order`)
SELECT 'Students Mark Entry & Analytics System',
'Academic grading and performance analytics web application enabling faculty to record, calculate, and report course grades systematically.',
'PHP, MySQL, HTML5, CSS3, Chart.js',
'Web Application',
'2024',
'',
'',
'assets/images/projects/marks.svg',
0,
5
WHERE NOT EXISTS (SELECT 1 FROM `projects` WHERE `title` LIKE 'Students Mark Entry%');

INSERT INTO `projects` (`title`, `description`, `technologies`, `category`, `year`, `live_url`, `github_url`, `image`, `is_featured`, `sort_order`)
SELECT 'Career Map & Pathway Explorer',
'An interactive guide and roadmap visualization helping students map out technical career pathways across networking, cloud, and web development.',
'HTML5, CSS3, JavaScript ES6+',
'Web Application',
'2024',
'',
'',
'assets/images/projects/careermap.svg',
0,
6
WHERE NOT EXISTS (SELECT 1 FROM `projects` WHERE `title` LIKE 'Career Map%');
