<?php
require_once __DIR__ . '/../config/config.php';

if (is_admin()) {
    header('Location: ' . url('admin/dashboard.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    try {
        $stmt = db()->prepare("SELECT id, username, password_hash FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            flash('success', 'Welcome back, ' . $admin['username'] . '!');
            header('Location: ' . url('admin/dashboard.php'));
            exit;
        }
        $error = 'Invalid username or password.';
    } catch (Throwable $e) {
        $error = 'Database authentication error: ' . $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="en" data-theme="obsidian">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Sign In | <?= e(APP_NAME) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="login-page">
  <div class="login-card-container">
    <form class="login-card" method="post" action="<?= e(url('admin/login.php')) ?>">
      <div class="login-header">
        <a class="brand" href="<?= e(url('index.php')) ?>">
          <span class="brand-mark"><span class="brand-letter">A</span></span>
          <span class="brand-text">Anjana<span class="brand-dot">.</span></span>
        </a>
        <p class="login-eyebrow">PORTFOLIO ADMINISTRATION</p>
        <h1>Welcome Back</h1>
        <p class="login-desc">Sign in to manage projects, review contact messages, and customize site features.</p>
      </div>

      <?php if ($error): ?>
        <div class="alert error" role="alert"><?= e($error) ?></div>
      <?php endif; ?>
      <?php if (isset($_GET['created'])): ?>
        <div class="alert success" role="alert">Admin account configured. Please sign in below.</div>
      <?php endif; ?>

      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

      <label class="form-field">
        <span class="field-label">Username</span>
        <input type="text" name="username" required autocomplete="username" value="admin" placeholder="Enter username">
      </label>

      <label class="form-field">
        <span class="field-label">Password</span>
        <input type="password" name="password" required autocomplete="current-password" placeholder="Enter password">
      </label>

      <button class="btn btn-primary full" type="submit">
        <span>Sign In to Dashboard</span> <span>↗</span>
      </button>

      <!-- Default credentials helper box for instant testing -->
      <div class="credentials-helper-box">
        <span class="cred-title">🔑 Default Admin Credentials</span>
        <div class="cred-row"><span>Username:</span> <code>admin</code></div>
        <div class="cred-row"><span>Password:</span> <code>Admin@2026!</code></div>
        <small class="cred-note">You can change your password anytime after signing in.</small>
      </div>

      <div class="login-footer-links">
        <a class="text-link" href="<?= e(url('index.php')) ?>">← Return to public website</a>
      </div>
    </form>
  </div>
</body>
</html>
