<?php
$projectImg = !empty($project['image']) ? $project['image'] : 'assets/images/projects/famconnect.svg';
$tags = array_filter(array_map('trim', explode(',', $project['technologies'] ?? '')));
$hasLive = !empty($project['live_url']);
$hasGithub = !empty($project['github_url']);
?>
<article class="project-card reveal" 
  data-id="<?= (int)$project['id'] ?>"
  data-title="<?= e($project['title']) ?>"
  data-category="<?= e($project['category'] ?? 'Project') ?>"
  data-year="<?= e($project['year'] ?? '') ?>"
  data-description="<?= e($project['description']) ?>"
  data-technologies="<?= e($project['technologies'] ?? '') ?>"
  data-image="<?= e(url($projectImg)) ?>"
  data-live="<?= e($project['live_url'] ?? '') ?>"
  data-github="<?= e($project['github_url'] ?? '') ?>">
  
  <div class="project-image-wrap">
    <img src="<?= e(url($projectImg)) ?>" alt="<?= e($project['title']) ?> showcase" loading="lazy">
    <div class="project-overlay">
      <button type="button" class="view-project-btn" title="Quick preview details">
        <span>Quick View</span> 🔍
      </button>
    </div>
    <span class="project-category-pill"><?= e($project['category'] ?? 'Project') ?></span>
    <?php if (!empty($project['year'])): ?>
      <span class="project-year-pill"><?= e($project['year']) ?></span>
    <?php endif; ?>
  </div>

  <div class="project-content">
    <div class="project-header-row">
      <h3 class="project-title"><?= e($project['title']) ?></h3>
      <span class="project-arrow-icon" title="View details">↗</span>
    </div>

    <p class="project-desc"><?= e($project['description']) ?></p>

    <div class="tag-list">
      <?php foreach ($tags as $tag): ?>
        <span class="tag-chip"><?= e($tag) ?></span>
      <?php endforeach; ?>
    </div>

    <div class="project-footer-actions">
      <?php if ($hasLive): ?>
        <a class="action-btn live-btn" href="<?= e($project['live_url']) ?>" target="_blank" rel="noopener">
          <span>Live Demo</span> ↗
        </a>
      <?php endif; ?>

      <?php if ($hasGithub): ?>
        <a class="action-btn code-btn" href="<?= e($project['github_url']) ?>" target="_blank" rel="noopener">
          <span>Source Code</span> ↗
        </a>
      <?php endif; ?>

      <?php if (!$hasLive && !$hasGithub): ?>
        <button type="button" class="action-btn outline-btn view-details-trigger">
          <span>Overview</span> ✦
        </button>
      <?php endif; ?>
    </div>
  </div>
</article>
