<?php
require_once __DIR__ . '/../config/config.php';

$count = (int)db()->query("SELECT COUNT(*) FROM admins")->fetchColumn();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $count === 0) {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!preg_match('/^[a-zA-Z0-9_.-]{4,40}$/', $username)) {
        $errors[] = 'Username must be 4–40 characters (letters, numbers, dot, dash, underscore).';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }

    if (!$errors) {
        $stmt = db()->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)");
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
        header('Location: ' . url('admin/login.php?created=1'));
        exit;
    }
}
?>
<!doctype html>
<html lang="en" data-theme="obsidian">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Setup Administrator | <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="login-page">
  <div class="login-card-container">
    <div class="login-card">
      <div class="login-header">
        <a class="brand" href="<?= e(url('index.php')) ?>">
          <span class="brand-mark"><span class="brand-letter">A</span></span>
          <span class="brand-text">Anjana<span class="brand-dot">.</span></span>
        </a>
        <p class="login-eyebrow">ONE-TIME CONFIGURATION</p>
        <h1>Portfolio Setup</h1>
      </div>

      <?php if ($count > 0): ?>
        <div class="alert success">
          <strong>Administrator Account Active</strong><br>
          An administrator account is already configured and ready to use.
        </div>
        <div class="credentials-helper-box">
          <span class="cred-title">🔑 Standard Login Details</span>
          <div class="cred-row"><span>Username:</span> <code>admin</code></div>
          <div class="cred-row"><span>Password:</span> <code>Admin@2026!</code></div>
        </div>
        <a href="<?= e(url('admin/login.php')) ?>" class="btn btn-primary full">Proceed to Admin Login ↗</a>
      <?php else: ?>
        <p class="muted">Create your initial administrator account below.</p>
        <?php foreach ($errors as $err): ?>
          <div class="alert error"><?= e($err) ?></div>
        <?php endforeach; ?>
        <form method="post" action="<?= e(url('admin/setup.php')) ?>">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <label class="form-field">
            <span class="field-label">Username</span>
            <input type="text" name="username" required minlength="4" maxlength="40" placeholder="e.g. anjana">
          </label>
          <label class="form-field">
            <span class="field-label">Password (Min 8 characters)</span>
            <input type="password" name="password" required minlength="8" placeholder="Choose a secure password">
          </label>
          <button class="btn btn-primary full" type="submit">Complete Setup ↗</button>
        </form>
      <?php endif; ?>

      <div class="login-footer-links">
        <a class="text-link" href="<?= e(url('index.php')) ?>">← Return to public website</a>
      </div>
    </div>
  </div>
</body>
</html>
