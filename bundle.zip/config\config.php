<?php
declare(strict_types=1);

define('APP_NAME', 'Anjana K Santhosh');
define('APP_TAGLINE', 'Computer Science & Network Engineering');
define('APP_LOCATION', 'Kerala, India');
define('APP_EMAIL', 'anjanaksanthosh2002@gmail.com');

// Auto-detect base URL dynamically across XAMPP subdirectories, virtual hosts, and PHP built-in servers
if (!defined('BASE_URL')) {
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $dir = dirname($script);
    if ($dir === '/' || $dir === '\\' || $dir === '.') {
        $detected = '';
    } else {
        if (str_ends_with($dir, '/admin')) {
            $dir = substr($dir, 0, -6);
        }
        $detected = rtrim($dir, '/');
    }
    define('BASE_URL', $detected);
}

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'anjana_portfolio');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Returns active PDO instance with automatic self-healing:
 * - Auto-creates MySQL database & tables if missing
 * - Seamlessly falls back to local SQLite if MySQL is offline or pdo_mysql is unavailable
 */
function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dbHost = DB_HOST;
    $dbName = DB_NAME;
    $dbUser = DB_USER;
    $dbPass = DB_PASS;

    // 1. Try connecting to MySQL directly
    try {
        $pdo = new PDO(
            "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
            $dbUser,
            $dbPass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            ]
        );
        ensure_portfolio_schema($pdo, 'mysql');
        return $pdo;
    } catch (Throwable $e) {
        // If the database does not exist on MySQL, connect to root server and auto-create it
        $msg = $e->getMessage();
        if (str_contains($msg, 'Unknown database') || str_contains($msg, '1049')) {
            try {
                $rootPdo = new PDO(
                    "mysql:host={$dbHost};charset=utf8mb4",
                    $dbUser,
                    $dbPass,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
                $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                
                $pdo = new PDO(
                    "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
                    $dbUser,
                    $dbPass,
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
                    ]
                );
                ensure_portfolio_schema($pdo, 'mysql');
                return $pdo;
            } catch (Throwable $createErr) {
                // Continue to SQLite fallback below
            }
        }

        // 2. Fallback to resilient local SQLite file if MySQL is offline
        try {
            $sqliteDir = __DIR__ . '/../database';
            if (!is_dir($sqliteDir)) {
                @mkdir($sqliteDir, 0777, true);
            }
            $sqliteFile = $sqliteDir . '/portfolio.sqlite';
            $pdo = new PDO('sqlite:' . $sqliteFile, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            ensure_portfolio_schema($pdo, 'sqlite');
            return $pdo;
        } catch (Throwable $sqliteErr) {
            throw new RuntimeException("Database error: could not connect to MySQL or SQLite. " . $e->getMessage());
        }
    }
}

/**
 * Ensures required tables and seed data exist without manual SQL import
 */
function ensure_portfolio_schema(PDO $pdo, string $driver): void {
    static $checked = false;
    if ($checked) {
        return;
    }
    $checked = true;

    $isSqlite = ($driver === 'sqlite');
    $autoInc = $isSqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
    $timestamp = $isSqlite ? 'DATETIME DEFAULT CURRENT_TIMESTAMP' : 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP';

    // Admins table
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id {$autoInc},
        username VARCHAR(40) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        created_at {$timestamp}
    )");

    // Projects table
    $pdo->exec("CREATE TABLE IF NOT EXISTS projects (
        id {$autoInc},
        title VARCHAR(150) NOT NULL,
        description TEXT NOT NULL,
        technologies VARCHAR(500) DEFAULT '',
        category VARCHAR(80) DEFAULT 'Other',
        year VARCHAR(20) DEFAULT '',
        live_url VARCHAR(500) DEFAULT '',
        github_url VARCHAR(500) DEFAULT '',
        image VARCHAR(500) DEFAULT '',
        is_featured TINYINT(1) NOT NULL DEFAULT 0,
        sort_order INT NOT NULL DEFAULT 0,
        created_at {$timestamp}
    )");

    // Messages table
    $pdo->exec("CREATE TABLE IF NOT EXISTS messages (
        id {$autoInc},
        name VARCHAR(100) NOT NULL,
        email VARCHAR(190) NOT NULL,
        subject VARCHAR(160) NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at {$timestamp}
    )");

    // Check if admins table is empty; if so, create default admin
    $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($adminCount === 0) {
        $defaultPassHash = password_hash('Admin@2026!', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)");
        $stmt->execute(['admin', $defaultPassHash]);
    }

    // Check if projects table is empty; if so, populate with rich default projects
    $projectCount = (int)$pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    if ($projectCount === 0) {
        $seedProjects = [
            [
                'title' => 'FamConnect – Farmers Marketplace',
                'description' => 'A direct-to-consumer agricultural portal built to empower local farmers, bypass predatory intermediaries, and connect households with fresh, sustainably sourced local harvests.',
                'technologies' => 'HTML5, CSS3, JavaScript (ES6+), Responsive UI',
                'category' => 'Web Development',
                'year' => '2025',
                'live_url' => 'https://asmapa.github.io/Farm_connect/',
                'github_url' => 'https://github.com/asmapa/Farm_connect',
                'image' => 'assets/images/projects/famconnect.svg',
                'is_featured' => 1,
                'sort_order' => 1
            ],
            [
                'title' => 'Placement Management System',
                'description' => 'Comprehensive campus placement platform with automated student eligibility filtering, recruiter company profiles, real-time interview round tracking, and analytics dashboards.',
                'technologies' => 'React.js, Tailwind CSS, Node.js, Express, PostgreSQL',
                'category' => 'Web Application',
                'year' => '2025',
                'live_url' => '',
                'github_url' => 'https://github.com/anjana-k-santhosh/placement-management',
                'image' => 'assets/images/projects/placement.svg',
                'is_featured' => 1,
                'sort_order' => 2
            ],
            [
                'title' => 'SaferNet – Anti-Scam SMS Shield',
                'description' => 'Android security utility developed during research at Kerala Police Academy to identify fraudulent SMS patterns, alert users to phishing hyperlinks, and provide one-tap cybercrime reporting.',
                'technologies' => 'Android, Java/Kotlin, AI Heuristics, Cyber Security',
                'category' => 'Mobile Application',
                'year' => '2025',
                'live_url' => '',
                'github_url' => 'https://github.com/anjana-k-santhosh/safernet-android',
                'image' => 'assets/images/projects/safernet.svg',
                'is_featured' => 1,
                'sort_order' => 3
            ],
            [
                'title' => 'Enterprise Employee Management',
                'description' => 'Robust enterprise HR management suite featuring department allocation, leave tracking, role-based access control, attendance logs, and automated payroll reporting.',
                'technologies' => 'PHP 8, MySQL, Bootstrap 5, JavaScript',
                'category' => 'Web Application',
                'year' => '2024',
                'live_url' => '',
                'github_url' => 'https://github.com/anjana-k-santhosh/employee-management-php',
                'image' => 'assets/images/projects/employee.svg',
                'is_featured' => 0,
                'sort_order' => 4
            ],
            [
                'title' => 'Students Mark Entry & Analytics System',
                'description' => 'Academic records database application for faculty to record internal and semester marks, compute grade point averages automatically, and generate exportable performance reports.',
                'technologies' => 'PHP, MySQL, HTML5, CSS Grid, Chart.js',
                'category' => 'Web Application',
                'year' => '2024',
                'live_url' => '',
                'github_url' => 'https://github.com/anjana-k-santhosh/student-mark-entry',
                'image' => 'assets/images/projects/marks.svg',
                'is_featured' => 0,
                'sort_order' => 5
            ],
            [
                'title' => 'Career Map & Pathway Explorer',
                'description' => 'Interactive roadmap guide allowing tech students and graduates to explore career tracks in networking, cybersecurity, and full-stack development with curated milestone checklists.',
                'technologies' => 'JavaScript, HTML5 Canvas, CSS3 Animations',
                'category' => 'Web Application',
                'year' => '2024',
                'live_url' => '',
                'github_url' => 'https://github.com/anjana-k-santhosh/career-map',
                'image' => 'assets/images/projects/careermap.svg',
                'is_featured' => 0,
                'sort_order' => 6
            ]
        ];

        $stmt = $pdo->prepare("INSERT INTO projects (title, description, technologies, category, year, live_url, github_url, image, is_featured, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($seedProjects as $p) {
            $stmt->execute([
                $p['title'],
                $p['description'],
                $p['technologies'],
                $p['category'],
                $p['year'],
                $p['live_url'],
                $p['github_url'],
                $p['image'],
                $p['is_featured'],
                $p['sort_order']
            ]);
        }
    }
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function url(string $path = ''): string {
    $base = rtrim(BASE_URL, '/');
    if ($path === '' || $path === '/') {
        return $base ?: '/';
    }
    return $base . '/' . ltrim($path, '/');
}

function is_admin(): bool {
    return !empty($_SESSION['admin_id']);
}

function require_admin(): void {
    if (!is_admin()) {
        header('Location: ' . url('admin/login.php'));
        exit;
    }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void {
    $sent = $_POST['csrf_token'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        exit('Your form session expired. Go back, refresh the page and try again.');
    }
}

function flash(string $key, ?string $message = null): ?string {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }
    $value = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $value;
}
