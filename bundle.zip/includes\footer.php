</main>
<footer class="site-footer">
  <div class="footer-grid section-wrap">
    <!-- Col 1: Bio -->
    <div class="footer-col footer-bio">
      <a class="brand" href="<?= e(url('index.php')) ?>">
        <span class="brand-mark">
          <span class="brand-letter">A</span>
        </span>
        <span class="brand-text">Anjana<span class="brand-dot">.</span></span>
      </a>
      <p class="footer-desc">
        Computer Science Graduate & Network Engineering Scholar building practical, resilient web solutions with modern tools.
      </p>
      <div class="footer-status-badge">
        <span class="pulsing-led"></span>
        <span>Based in Kerala, India · <span id="footerClock">IST</span></span>
      </div>
    </div>

    <!-- Col 2: Navigation -->
    <div class="footer-col">
      <h4 class="footer-heading">Navigation</h4>
      <ul class="footer-nav">
        <li><a href="<?= e(url('index.php')) ?>">Home</a></li>
        <li><a href="<?= e(url('about.php')) ?>">About Me</a></li>
        <li><a href="<?= e(url('projects.php')) ?>">Projects</a></li>
        <li><a href="<?= e(url('skills.php')) ?>">Technical Skills</a></li>
        <li><a href="<?= e(url('education.php')) ?>">Education & Journey</a></li>
        <li><a href="<?= e(url('contact.php')) ?>">Get In Touch</a></li>
      </ul>
    </div>

    <!-- Col 3: Focus Areas -->
    <div class="footer-col">
      <h4 class="footer-heading">Specializations</h4>
      <ul class="footer-tags">
        <li>Computer Networks</li>
        <li>Full-Stack Development</li>
        <li>PHP & MySQL Architecture</li>
        <li>React & Modern JavaScript</li>
        <li>Cybersecurity & Scam Defense</li>
        <li>Database Management</li>
      </ul>
    </div>

    <!-- Col 4: Connect & Admin -->
    <div class="footer-col">
      <h4 class="footer-heading">Connect</h4>
      <div class="footer-socials">
        <a href="https://github.com/" target="_blank" rel="noopener" class="social-chip">
          <span>GitHub</span> ↗
        </a>
        <a href="https://www.linkedin.com/" target="_blank" rel="noopener" class="social-chip">
          <span>LinkedIn</span> ↗
        </a>
        <a href="mailto:<?= e(APP_EMAIL) ?>" class="social-chip">
          <span>Email</span> ↗
        </a>
      </div>
      <div class="footer-actions">
        <button type="button" class="terminal-trigger-btn" id="openTerminalBtn">
          <span>&gt;_</span> Open Interactive Terminal
        </button>
      </div>
    </div>
  </div>

  <!-- Bottom Bar -->
  <div class="footer-bottom section-wrap">
    <div class="copyright">
      © <?= date('Y') ?> <?= e(APP_NAME) ?>. Crafted with passion, PHP &amp; Clean Code.
    </div>
    <div class="footer-links">
      <a href="<?= e(url('admin/login.php')) ?>" class="admin-pill-link">
        <span class="lock-icon">🔒</span> Admin Portal
      </a>
      <a href="#siteHeader" class="back-top" id="backToTop" aria-label="Scroll back to top">
        <span>Back to Top</span> ↑
      </a>
    </div>
  </div>
</footer>
</div><!-- /.site-shell -->

<!-- RESUME MODAL -->
<div class="modal-backdrop" id="resumeModal" role="dialog" aria-modal="true" aria-labelledby="resumeTitle" hidden>
  <div class="modal-card resume-card">
    <div class="modal-header">
      <div>
        <h3 id="resumeTitle" class="modal-title">Curriculum Vitae</h3>
        <p class="modal-subtitle">Anjana K Santhosh · Academic &amp; Technical Profile</p>
      </div>
      <div class="modal-ctrls">
        <button type="button" class="btn btn-sm btn-primary" onclick="window.print()">
          Print / Save PDF 🖨️
        </button>
        <button type="button" class="modal-close-btn" id="closeResumeBtn" aria-label="Close modal">✕</button>
      </div>
    </div>
    <div class="resume-scroll-body" id="printableResume">
      <div class="resume-paper">
        <header class="resume-header">
          <div>
            <h1>Anjana K Santhosh</h1>
            <p class="resume-role">Computer Science Graduate · M.Tech in Network Engineering</p>
            <p class="resume-contact-line">
              <span>📍 Kerala, India</span> · 
              <a href="mailto:<?= e(APP_EMAIL) ?>"><?= e(APP_EMAIL) ?></a> · 
              <a href="https://github.com/" target="_blank">GitHub</a> · 
              <a href="https://www.linkedin.com/" target="_blank">LinkedIn</a>
            </p>
          </div>
        </header>

        <section class="resume-section">
          <h2>Academic Qualifications</h2>
          <div class="resume-entry">
            <div class="entry-row">
              <h3>M.Tech – Network Engineering</h3>
              <span class="entry-year">2026 – Present</span>
            </div>
            <p class="entry-org">Government Engineering College, Barton Hill</p>
            <p class="entry-desc">Advanced postgraduate focus on routing algorithms, network security, packet analysis, and high-performance distributed systems.</p>
          </div>
          <div class="resume-entry">
            <div class="entry-row">
              <h3>B.Tech – Computer Science and Engineering</h3>
              <span class="entry-year">Graduated 2026</span>
            </div>
            <p class="entry-org">Rajiv Gandhi Institute of Technology (RIT), Kottayam</p>
            <p class="entry-desc">Core curriculum covering Operating Systems, Database Management Systems, Computer Networks, and Object-Oriented Software Engineering.</p>
          </div>
          <div class="resume-entry">
            <div class="entry-row">
              <h3>Diploma – Computer Science and Engineering</h3>
              <span class="entry-year">Completed 2023</span>
            </div>
            <p class="entry-org">State Board of Technical Education</p>
            <p class="entry-desc">Graduated with distinction (CGPA 9.3) building strong foundational programming and algorithmic fundamentals.</p>
          </div>
        </section>

        <section class="resume-section">
          <h2>Technical Core Skills</h2>
          <div class="resume-skills-grid">
            <div>
              <strong>Languages &amp; Web:</strong> PHP 8, JavaScript (ES6+), HTML5, CSS3, SQL
            </div>
            <div>
              <strong>Frameworks &amp; Libraries:</strong> React.js, Node.js, Express.js, Tailwind CSS, Bootstrap
            </div>
            <div>
              <strong>Databases:</strong> MySQL, PostgreSQL, SQLite, PDO Prepared Statements
            </div>
            <div>
              <strong>Networking &amp; Security:</strong> Computer Networks, Routing, Packet Inspection, AI Threat Analysis
            </div>
            <div>
              <strong>Tools &amp; Environments:</strong> Git, GitHub, VS Code, Postman, Apache, XAMPP, Linux CLI
            </div>
          </div>
        </section>

        <section class="resume-section">
          <h2>Key Projects</h2>
          <div class="resume-entry">
            <div class="entry-row">
              <h3>FamConnect – Direct Farmers Marketplace</h3>
              <span class="entry-year">2025</span>
            </div>
            <p class="entry-desc">Direct agricultural trading platform reducing intermediary markups and connecting local growers to buyers. Developed for TinkerHub Tink-Her-Hack.</p>
          </div>
          <div class="resume-entry">
            <div class="entry-row">
              <h3>SaferNet – Anti-Scam SMS Shield</h3>
              <span class="entry-year">2025</span>
            </div>
            <p class="entry-desc">Android application researched and built during an internship with the Kerala Police Academy for SMS scam identification, heuristic scoring, and one-tap crime reporting.</p>
          </div>
          <div class="resume-entry">
            <div class="entry-row">
              <h3>Placement Management System</h3>
              <span class="entry-year">2025</span>
            </div>
            <p class="entry-desc">Web portal built using React and Node.js for tracking campus placement statistics, candidate eligibility rules, and interview round notifications.</p>
          </div>
        </section>

        <section class="resume-section">
          <h2>Honors, Internships &amp; Activities</h2>
          <ul class="resume-bullet-list">
            <li><strong>Kerala Police Academy Internship:</strong> Developed SaferNet mobile application for scam awareness and reporting.</li>
            <li><strong>TinkerHub Tink-Her-Hack Hackathon:</strong> Conceptualized and prototyped the FamConnect agricultural platform.</li>
            <li><strong>Leadership &amp; Service:</strong> Active NSS Volunteer, Scouts &amp; Guides participant, and former IEDC executive member.</li>
          </ul>
        </section>
      </div>
    </div>
  </div>
</div>

<!-- INTERACTIVE TERMINAL DRAWER -->
<div class="terminal-drawer" id="terminalDrawer" role="region" aria-label="Interactive Developer Console" hidden>
  <div class="terminal-bar">
    <div class="term-dots">
      <span class="t-dot t-red" id="closeTerminalBtn" title="Close Terminal"></span>
      <span class="t-dot t-yellow"></span>
      <span class="t-dot t-green"></span>
    </div>
    <div class="term-title">terminal: anjana@portfolio ~ (bash)</div>
    <div class="term-hints">type <kbd>help</kbd> for options</div>
  </div>
  <div class="terminal-content" id="terminalOutput">
    <div class="term-line banner">
      <pre>
   ___         _                   _  __  ___             __  __             _   
  / _ \       (_)                 | |/ / / ___|           | | | |           | |  
 / /_\ \_ __   _  __ _ _ __   __ _| ' /  \ `--.  __ _ _ __ | |_| |__   ___  ___| |_ 
 |  _  | '_ \ | |/ _` | '_ \ / _` |  <    `--. \/ _` | '_ \| __| '_ \ / _ \/ __| __|
 | | | | | | || | (_| | | | | (_| | . \  /\__/ / (_| | | | | |_| | | | (_) \__ \ |_ 
 \_| |_/_| |_|/ |\__,_|_| |_|\__,_|_|\_\ \____/ \__,_|_| |_|\__|_| |_|\___/|___/\__|
            _/ |                                                                     
           |__/  Type 'help' or click commands below.
      </pre>
    </div>
    <div class="term-line info">Welcome to Anjana's interactive terminal console. Explore my background via CLI!</div>
  </div>
  <div class="terminal-chips">
    <button type="button" class="term-chip" data-cmd="help">help</button>
    <button type="button" class="term-chip" data-cmd="skills">skills</button>
    <button type="button" class="term-chip" data-cmd="projects">projects</button>
    <button type="button" class="term-chip" data-cmd="education">education</button>
    <button type="button" class="term-chip" data-cmd="contact">contact</button>
    <button type="button" class="term-chip" data-cmd="whoami">whoami</button>
    <button type="button" class="term-chip" data-cmd="clear">clear</button>
  </div>
  <form class="terminal-input-row" id="terminalForm">
    <span class="term-prompt">visitor@anjana-portfolio:~$</span>
    <input type="text" class="term-input" id="terminalInput" autocomplete="off" spellcheck="false" placeholder="Type a command...">
  </form>
</div>

<!-- PROJECT DETAIL MODAL -->
<div class="modal-backdrop" id="projectModal" role="dialog" aria-modal="true" aria-labelledby="modalProjectTitle" hidden>
  <div class="modal-card project-modal-card">
    <button type="button" class="modal-close-btn" id="closeProjectModalBtn" aria-label="Close modal">✕</button>
    <div class="modal-project-content" id="modalProjectBody">
      <!-- Populated dynamically via JS -->
    </div>
  </div>
</div>

<script>
  window.PORTFOLIO_BASE = <?= json_encode(rtrim(BASE_URL, '/')) ?>;
  window.PORTFOLIO_EMAIL = <?= json_encode(APP_EMAIL) ?>;
</script>
<script src="<?= e(url('assets/js/main.js')) ?>"></script>
</body>
</html>
